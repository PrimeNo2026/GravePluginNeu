package de.grave;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class GraveListener implements Listener {

    private final GraveManager manager;

    public GraveListener(GraveManager manager) {
        this.manager = manager;
    }

    // ------------------------------------------------------------------ Tod

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        if (event.getKeepInventory()) {
            return;
        }

        List<ItemStack> drops = event.getDrops();
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack drop : drops) {
            if (!GraveManager.isEmpty(drop)) {
                items.add(drop.clone());
            }
        }
        if (items.isEmpty()) {
            return;
        }

        Player player = event.getPlayer();
        try {
            Location where = manager.createGrave(player, items);
            drops.clear(); // erst nach erfolgreichem Erstellen, sonst bleiben die normalen Drops erhalten
            player.sendMessage(Component.text(
                    "Dein Grab ist bei X: " + where.getBlockX()
                            + " Y: " + where.getBlockY()
                            + " Z: " + where.getBlockZ()
                            + " (" + where.getWorld().getName() + ")",
                    NamedTextColor.GRAY));
        } catch (RuntimeException ex) {
            manager.getLogger().log(Level.SEVERE,
                    "Grab konnte nicht erstellt werden, normale Drops bleiben erhalten.", ex);
        }
    }

    // ------------------------------------------------------------------ Rechtsklick

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Interaction interaction)) {
            return;
        }
        if (!manager.isGrave(interaction)) {
            return;
        }
        event.setCancelled(true);
        if (event.getHand() != EquipmentSlot.HAND) {
            return; // der Rechtsklick wird pro Hand einmal gemeldet
        }
        manager.open(event.getPlayer(), interaction);
    }

    // ------------------------------------------------------------------ Schutz

    /** Graeber sind nicht zerstoerbar. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (entity instanceof Interaction interaction && manager.isGrave(interaction)) {
            event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ Inventar

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof GraveHolder holder)) {
            return;
        }

        GraveManager.Session session = manager.getSession(holder.getGraveId());
        if (session == null) {
            event.setCancelled(true);
            return;
        }

        Inventory clicked = event.getClickedInventory();
        if (clicked == null) {
            return; // Klick ausserhalb des Fensters
        }

        if (clicked == top) {
            if (isTakeAction(event)) {
                manager.scheduleSync(session);
            } else {
                event.setCancelled(true);
            }
            return;
        }

        // Klick im eigenen Inventar: nichts darf ins Grab wandern.
        InventoryAction action = event.getAction();
        if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY
                || action == InventoryAction.COLLECT_TO_CURSOR) {
            event.setCancelled(true);
        }
    }

    /** Nur Herausnehmen ist erlaubt. */
    private boolean isTakeAction(InventoryClickEvent event) {
        if (!GraveManager.isEmpty(event.getCursor())) {
            return false;
        }
        return switch (event.getAction()) {
            case PICKUP_ALL, PICKUP_HALF, PICKUP_ONE, PICKUP_SOME,
                 MOVE_TO_OTHER_INVENTORY, DROP_ALL_SLOT, DROP_ONE_SLOT -> true;
            case HOTBAR_SWAP -> {
                ItemStack other;
                if (event.getClick() == ClickType.SWAP_OFFHAND) {
                    other = event.getWhoClicked().getInventory().getItemInOffHand();
                } else {
                    int button = event.getHotbarButton();
                    if (button < 0 || button > 8) {
                        yield false;
                    }
                    other = event.getWhoClicked().getInventory().getItem(button);
                }
                yield GraveManager.isEmpty(other);
            }
            default -> false;
        };
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof GraveHolder)) {
            return;
        }
        int size = top.getSize();
        for (int rawSlot : event.getRawSlots()) {
            if (rawSlot < size) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof GraveHolder holder)) {
            return;
        }
        GraveManager.Session session = manager.getSession(holder.getGraveId());
        if (session != null) {
            manager.scheduleSync(session);
        }
    }
}
