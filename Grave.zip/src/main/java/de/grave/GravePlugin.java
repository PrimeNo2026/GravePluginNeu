package de.grave;

import org.bukkit.plugin.java.JavaPlugin;

public final class GravePlugin extends JavaPlugin {

    private GraveManager manager;

    @Override
    public void onEnable() {
        this.manager = new GraveManager(this);
        getServer().getPluginManager().registerEvents(new GraveListener(manager), this);
        getLogger().info("Grave aktiviert.");
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.shutdown();
        }
    }
}
