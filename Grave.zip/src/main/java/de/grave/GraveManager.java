package de.grave;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

/**
 * Erstellt, oeffnet und entfernt Graeber.
 *
 * Ein Grab besteht aus drei Entities (alle ohne Kollision, ohne KI, ohne Drops):
 *  - Interaction : unsichtbare Klick-Box, speichert die Items im PersistentDataContainer
 *  - ItemDisplay : der Skelettschaedel
 *  - TextDisplay : der Name des Spielers
 */
public final class GraveManager {

    private static final float HITBOX_WIDTH = 0.8f;
    private static final float HITBOX_HEIGHT = 0.8f;
    private static final double SKULL_Y = 0.3;
    private static final double LABEL_Y = 0.85;

    private final GravePlugin plugin;
    private final NamespacedKey keyItems;
    private final NamespacedKey keyOwner;
    private final NamespacedKey keySkull;
    private final NamespacedKey keyLabel;
    private final Map<UUID, Session> sessions = new HashMap<>();

    /** Offenes Grab im Speicher (gemeinsames Inventar fuer alle, die gerade hineinschauen). */
    static final class Session {
        final UUID graveId;
        final Location location;
        final Inventory inventory;
        final Deque<ItemStack> overflow = new ArrayDeque<>();
        boolean syncPending = false;

        Session(UUID graveId, Location location, Inventory inventory) {
            this.graveId = graveId;
            this.location = location;
            this.inventory = inventory;
        }
    }

    public GraveManager(GravePlugin plugin) {
        this.plugin = plugin;
        this.keyItems = new NamespacedKey(plugin, "grave_items");
        this.keyOwner = new NamespacedKey(plugin, "grave_owner");
        this.keySkull = new NamespacedKey(plugin, "grave_skull");
        this.keyLabel = new NamespacedKey(plugin, "grave_label");
    }

    public Logger getLogger() {
        return plugin.getLogger();
    }

    public static boolean isEmpty(ItemStack item) {
        return item == null || item.isEmpty();
    }

    // ------------------------------------------------------------------ erstellen

    /** Erstellt ein Grab und gibt dessen Position zurueck. Wirft bei Fehlern eine RuntimeException. */
    public Location createGrave(Player player, List<ItemStack> items) {
        Location death = player.getLocation();
        Location base = findGraveLocation(death);
        World world = base.getWorld();
        String owner = player.getName();
        byte[] data = ItemStack.serializeItemsAsBytes(items);
        float yaw = death.getYaw() + 180.0f;

        List<Entity> spawned = new ArrayList<>();
        try {
            Location skullLoc = base.clone().add(0.0, SKULL_Y, 0.0);
            skullLoc.setYaw(yaw);
            skullLoc.setPitch(0.0f);
            ItemDisplay skull = world.spawn(skullLoc, ItemDisplay.class, display -> {
                display.setItemStack(new ItemStack(Material.SKELETON_SKULL));
                display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
                display.setGravity(false);
                display.setInvulnerable(true);
                display.setPersistent(true);
            });
            spawned.add(skull);

            Location labelLoc = base.clone().add(0.0, LABEL_Y, 0.0);
            TextDisplay label = world.spawn(labelLoc, TextDisplay.class, text -> {
                text.text(Component.text(owner, NamedTextColor.WHITE));
                text.setBillboard(Display.Billboard.CENTER);
                text.setGravity(false);
                text.setInvulnerable(true);
                text.setPersistent(true);
            });
            spawned.add(label);

            String skullId = skull.getUniqueId().toString();
            String labelId = label.getUniqueId().toString();
            Interaction hitbox = world.spawn(base, Interaction.class, box -> {
                box.setInteractionWidth(HITBOX_WIDTH);
                box.setInteractionHeight(HITBOX_HEIGHT);
                box.setGravity(false);
                box.setInvulnerable(true);
                box.setPersistent(true);
                PersistentDataContainer pdc = box.getPersistentDataContainer();
                pdc.set(keyItems, PersistentDataType.BYTE_ARRAY, data);
                pdc.set(keyOwner, PersistentDataType.STRING, owner);
                pdc.set(keySkull, PersistentDataType.STRING, skullId);
                pdc.set(keyLabel, PersistentDataType.STRING, labelId);
            });
            spawned.add(hitbox);
        } catch (RuntimeException ex) {
            for (Entity entity : spawned) {
                entity.remove();
            }
            throw ex;
        }
        return base;
    }

    /** Sucht die Stelle, an der das Grab stehen soll (auf dem Boden unter dem Todesort). */
    private Location findGraveLocation(Location death) {
        World world = death.getWorld();
        int minY = world.getMinHeight();
        int maxY = world.getMaxHeight() - 1;

        int x = death.getBlockX();
        int z = death.getBlockZ();
        int y = death.getBlockY();

        // Tod im Void: Grab bleibt an der untersten moeglichen Stelle (Welt-Untergrenze) an derselben X/Z-Position.
        y = Math.max(minY, Math.min(y, maxY));

        // Steckt der Todesort in einem festen Block, nach oben ausweichen.
        int guard = 0;
        while (!world.getBlockAt(x, y, z).isPassable() && y < maxY && guard < 16) {
            y++;
            guard++;
        }

        // Nach unten bis zum Boden laufen.
        while (y > minY) {
            Block below = world.getBlockAt(x, y - 1, z);
            if (!below.isPassable()) {
                break;
            }
            y--;
        }

        return new Location(world, x + 0.5, y, z + 0.5);
    }

    // ------------------------------------------------------------------ erkennen

    public boolean isGrave(Interaction interaction) {
        return interaction.getPersistentDataContainer().has(keyItems, PersistentDataType.BYTE_ARRAY);
    }

    Session getSession(UUID graveId) {
        return sessions.get(graveId);
    }

    // ------------------------------------------------------------------ oeffnen

    public void open(Player player, Interaction interaction) {
        UUID id = interaction.getUniqueId();
        Session session = sessions.get(id);

        if (session == null) {
            PersistentDataContainer pdc = interaction.getPersistentDataContainer();
            byte[] data = pdc.get(keyItems, PersistentDataType.BYTE_ARRAY);
            if (data == null) {
                return;
            }

            List<ItemStack> items = new ArrayList<>();
            try {
                for (ItemStack item : ItemStack.deserializeItemsFromBytes(data)) {
                    if (!isEmpty(item)) {
                        items.add(item);
                    }
                }
            } catch (RuntimeException ex) {
                plugin.getLogger().log(Level.SEVERE, "Grab bei " + interaction.getLocation() + " ist beschaedigt.", ex);
                player.sendMessage(Component.text("Dieses Grab ist beschaedigt.", NamedTextColor.RED));
                return;
            }

            if (items.isEmpty()) {
                removeParts(interaction);
                return;
            }

            String owner = pdc.get(keyOwner, PersistentDataType.STRING);
            if (owner == null) {
                owner = "Unbekannt";
            }

            GraveHolder holder = new GraveHolder(id);
            int rows = Math.min(6, Math.max(1, (items.size() + 8) / 9));
            Inventory inventory = Bukkit.createInventory(holder, rows * 9, Component.text("Grab von " + owner));
            holder.setInventory(inventory);

            session = new Session(id, interaction.getLocation(), inventory);
            for (int i = 0; i < items.size(); i++) {
                if (i < inventory.getSize()) {
                    inventory.setItem(i, items.get(i));
                } else {
                    session.overflow.add(items.get(i));
                }
            }
            sessions.put(id, session);
        }

        player.openInventory(session.inventory);
    }

    // ------------------------------------------------------------------ synchronisieren

    /** Plant einen Abgleich fuer den naechsten Tick (nachdem der Klick ausgefuehrt wurde). */
    void scheduleSync(Session session) {
        if (session.syncPending || !plugin.isEnabled()) {
            return;
        }
        session.syncPending = true;
        Bukkit.getScheduler().runTask(plugin, () -> {
            session.syncPending = false;
            sync(session);
        });
    }

    /** Speichert den aktuellen Inhalt im Grab oder entfernt das Grab, wenn es leer ist. */
    private void sync(Session session) {
        if (sessions.get(session.graveId) != session) {
            return;
        }

        Inventory inventory = session.inventory;

        // Falls mehr als 54 Stacks vorhanden waren: freie Plaetze mit dem Rest auffuellen.
        while (!session.overflow.isEmpty()) {
            int slot = inventory.firstEmpty();
            if (slot < 0) {
                break;
            }
            inventory.setItem(slot, session.overflow.pollFirst());
        }

        List<ItemStack> remaining = new ArrayList<>();
        for (ItemStack item : inventory.getContents()) {
            if (!isEmpty(item)) {
                remaining.add(item);
            }
        }
        remaining.addAll(session.overflow);

        if (remaining.isEmpty()) {
            removeGrave(session);
            return;
        }

        Interaction hitbox = findInteraction(session);
        if (hitbox != null) {
            hitbox.getPersistentDataContainer().set(
                    keyItems, PersistentDataType.BYTE_ARRAY, ItemStack.serializeItemsAsBytes(remaining));
        }

        if (inventory.getViewers().isEmpty()) {
            sessions.remove(session.graveId);
        }
    }

    private Interaction findInteraction(Session session) {
        Entity entity = Bukkit.getEntity(session.graveId);
        if (entity == null) {
            session.location.getChunk(); // laedt den Chunk, falls noetig
            entity = Bukkit.getEntity(session.graveId);
        }
        if (entity instanceof Interaction interaction) {
            return interaction;
        }
        return null;
    }

    // ------------------------------------------------------------------ entfernen

    private void removeGrave(Session session) {
        sessions.remove(session.graveId);
        for (HumanEntity viewer : new ArrayList<>(session.inventory.getViewers())) {
            viewer.closeInventory();
        }
        Interaction hitbox = findInteraction(session);
        if (hitbox != null) {
            removeParts(hitbox);
        }
    }

    private void removeParts(Interaction hitbox) {
        PersistentDataContainer pdc = hitbox.getPersistentDataContainer();
        removeByStoredId(pdc.get(keySkull, PersistentDataType.STRING));
        removeByStoredId(pdc.get(keyLabel, PersistentDataType.STRING));
        hitbox.remove();
    }

    private void removeByStoredId(String stored) {
        if (stored == null) {
            return;
        }
        try {
            Entity entity = Bukkit.getEntity(UUID.fromString(stored));
            if (entity != null) {
                entity.remove();
            }
        } catch (IllegalArgumentException ignored) {
            // ungueltige UUID: nichts zu tun
        }
    }

    /** Beim Abschalten des Plugins alle offenen Graeber sichern. */
    public void shutdown() {
        for (Session session : new ArrayList<>(sessions.values())) {
            sync(session);
            if (sessions.get(session.graveId) == session) {
                for (HumanEntity viewer : new ArrayList<>(session.inventory.getViewers())) {
                    viewer.closeInventory();
                }
            }
        }
        sessions.clear();
    }
}
